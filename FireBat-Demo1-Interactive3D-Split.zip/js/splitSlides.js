/**
 * Split Slide Deck Definition
 * Content is clearly displayed on the left column,
 * while the right viewport controls and updates the live 3D scene.
 */
(function (global) {
  'use strict';

  const SLIDES = [
    // -------------------------------------------------------------
    // SLIDE 1: COVER
    // -------------------------------------------------------------
    {
      id: 'cover',
      kicker: 'TUGAS MINGGU 13 · DEMO 1',
      title: 'FireBat: Sinergi Cerdas Dua Algoritma',
      lead: 'Menjawab tantangan penjadwalan cloud melalui penggabungan metaheuristik Firefly dan Bat.',
      mode3d: 'swarm',
      badge3d: '3D Optimization Space · Surface & Swarm',
      renderLeft(container, api) {
        container.innerHTML = `
          <span class="slide-kicker">TUGAS MINGGU 13 · DEMO 1</span>
          <h1 class="slide-title">
            FireBat: Sinergi Cerdas<br/>
            <span style="background:linear-gradient(135deg, #38bdf8 0%, #fbbf24 50%, #a855f7 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">
              Firefly × Bat Algorithm
            </span>
          </h1>
          <p class="slide-lead">
            Pola hybrid metaheuristik + metaheuristik untuk mencapai waktu selesai (makespan) paling cepat dan pembagian beban server yang rata sempurna.
          </p>

          <div class="grid-2">
            <div class="clean-card card-cyan">
              <div class="stat-label">Sumber Ilmiah Bereputasi</div>
              <div style="font-size:20px;font-weight:700;margin:6px 0;color:var(--cyan);">Springer Nature</div>
              <div class="stat-desc">Journal of Cloud Computing (2026)</div>
            </div>
            <div class="clean-card card-gold">
              <div class="stat-label">Algoritma Terpilih</div>
              <div style="font-size:20px;font-weight:700;margin:6px 0;color:var(--amber);">FireBat</div>
              <div class="stat-desc">Menggabungkan FA (Eksplorasi) + BA (Eksploitasi)</div>
            </div>
          </div>

          <div style="margin-top:10px;">
            <button class="pill-btn primary" id="btn-start" style="padding:12px 28px;font-size:16px;">
              Mulai Tur Presentasi ➔
            </button>
          </div>
        `;
        container.querySelector('#btn-start').onclick = () => api.next();
      },
      renderRightControls(container, v3d) {
        container.innerHTML = `
          <div style="display:flex;align-items:center;gap:10px;font-size:14px;color:var(--ink-secondary);">
            <span style="color:var(--amber);font-weight:700;">🎮 Model 3D Interaktif:</span>
            <span>Tahan klik kiri mouse pada kotak di atas untuk memutar kamera!</span>
          </div>
          <button class="pill-btn primary" id="btn-next-step">Berikutnya ➔</button>
        `;
        container.querySelector('#btn-next-step').onclick = () => window.SplitDeckApi.next();
      },
      notes: 'Buka presentasi. Tunjukkan bahwa di sebelah kanan adalah kanvas 3D interaktif yang merepresentasikan ruang pencarian optimasi kontinu.'
    },

    // -------------------------------------------------------------
    // SLIDE 2: DILEMA
    // -------------------------------------------------------------
    {
      id: 'dilema',
      kicker: 'LATAR BELAKANG & MOTIVASI',
      title: 'Dilema Dua Metode Sebelumnya',
      lead: 'Mengapa algoritma tunggal (Firefly atau Bat) masih memiliki celah?',
      mode3d: 'swarm',
      badge3d: 'Analisis Celah Algoritma Tunggal',
      renderLeft(container) {
        container.innerHTML = `
          <span class="slide-kicker">LATAR BELAKANG &amp; MOTIVASI</span>
          <h1 class="slide-title">Dilema Dua Metode Sebelumnya</h1>
          <p class="slide-lead">
            Firefly jago mencari jalan tapi lambat, sedangkan Bat cepat menukik tapi mudah terjebak di lembah lokal.
          </p>

          <div class="clean-card card-cyan">
            <div style="display:flex;justify-content:space-between;align-items:center;">
              <span class="stat-label" style="color:var(--cyan);">Metode Sebelumnya #1</span>
              <span style="font-family:var(--font-mono);font-size:14px;color:var(--cyan);">FA</span>
            </div>
            <div class="stat-num" style="color:var(--cyan);font-size:32px;">Firefly Algorithm</div>
            <p style="color:var(--ink-secondary);font-size:15px;line-height:1.5;margin:0 0 10px;">
              Sangat teliti menyusuri seluruh ruang pencarian berkat daya tarik cahaya (Exploration).
            </p>
            <div style="padding:8px 12px;border-radius:10px;background:rgba(244,63,94,0.12);border:1px solid rgba(244,63,94,0.3);color:var(--coral);font-size:14px;font-weight:600;">
              ✗ Celah: Lambat sekali mengerucut (konvergensi) di iterasi akhir.
            </div>
          </div>

          <div class="clean-card card-violet">
            <div style="display:flex;justify-content:space-between;align-items:center;">
              <span class="stat-label" style="color:var(--violet);">Metode Sebelumnya #2</span>
              <span style="font-family:var(--font-mono);font-size:14px;color:var(--violet);">BA</span>
            </div>
            <div class="stat-num" style="color:var(--violet);font-size:32px;">Bat Algorithm</div>
            <p style="color:var(--ink-secondary);font-size:15px;line-height:1.5;margin:0 0 10px;">
              Melesat sangat kencang langsung menuju mangsa terbaik lewat sonar ekolokasi (Exploitation).
            </p>
            <div style="padding:8px 12px;border-radius:10px;background:rgba(244,63,94,0.12);border:1px solid rgba(244,63,94,0.3);color:var(--coral);font-size:14px;font-weight:600;">
              ✗ Celah: Mudah terkecoh dan terjebak di lembah samping (local optimum).
            </div>
          </div>
        `;
      },
      renderRightControls(container, v3d) {
        container.innerHTML = `
          <div style="display:flex;gap:8px;">
            <button class="pill-btn" id="f-fa" style="border-color:var(--cyan);color:var(--cyan);">Sorot Firefly (Cyan)</button>
            <button class="pill-btn" id="f-ba" style="border-color:var(--violet);color:var(--violet);">Sorot Bat (Violet)</button>
          </div>
          <button class="pill-btn primary" id="btn-next-step">Lanjut ke Solusi ➔</button>
        `;
        container.querySelector('#f-fa').onclick = () => v3d.setFilterSwarm('fa');
        container.querySelector('#f-ba').onclick = () => v3d.setFilterSwarm('ba');
        container.querySelector('#btn-next-step').onclick = () => window.SplitDeckApi.next();
      },
      notes: 'Slide 2: Tekankan trade-off alami antara Eksplorasi (Firefly) dan Eksploitasi (Bat). Di kanvas kanan, audiens bisa menyorot bola cyan (kunang-kunang) dan bola violet (kelelawar).'
    },

    // -------------------------------------------------------------
    // SLIDE 3: 3 PILAR FIREBAT
    // -------------------------------------------------------------
    {
      id: 'pilar',
      kicker: 'CARA KERJA SEDERHANA',
      title: 'Tiga Pilar Solusi FireBat',
      lead: 'Bagaimana FireBat bekerja menuntaskan kelemahan kedua metode pendahulunya?',
      mode3d: 'swarm',
      badge3d: 'Arsitektur 3 Tahap FireBat',
      renderLeft(container) {
        container.innerHTML = `
          <span class="slide-kicker">CARA KERJA SEDERHANA</span>
          <h1 class="slide-title">Tiga Pilar Solusi FireBat</h1>
          <p class="slide-lead">
            Eksplorasi ganda di awal, seleksi bibit unggul, lalu polesan akhir penyeimbang server.
          </p>

          <div class="clean-card card-cyan">
            <div style="font-weight:700;color:var(--cyan);font-size:14px;">TAHAP 01</div>
            <div style="font-size:22px;font-weight:800;margin:4px 0 8px;">Populasi Awal Ganda</div>
            <p style="font-size:15px;color:var(--ink-secondary);line-height:1.5;margin:0;">
              Kawanan dibagi dua: regu Kunang-kunang menyisir seluruh wilayah, sementara regu Kelelawar menguji kekuatan titik awal secara bersamaan.
            </p>
          </div>

          <div class="clean-card card-gold">
            <div style="font-weight:700;color:var(--amber);font-size:14px;">TAHAP 02</div>
            <div style="font-size:22px;font-weight:800;margin:4px 0 8px;color:var(--amber);">Seleksi Kolam Elit (Elite Pool)</div>
            <p style="font-size:15px;color:var(--ink-secondary);line-height:1.5;margin:0;">
              Hasil terbaik kedua regu digabungkan. Jadwal yang paling singkat waktu kerjanya disaring untuk babak penukikan presisi.
            </p>
          </div>

          <div class="clean-card card-violet">
            <div style="font-weight:700;color:var(--violet);font-size:14px;">TAHAP 03</div>
            <div style="font-size:22px;font-weight:800;margin:4px 0 8px;">Migrasi Penyeimbang Beban (SD)</div>
            <p style="font-size:15px;color:var(--ink-secondary);line-height:1.5;margin:0;">
              Jika masih ada server yang sedikit kepenuhan, sistem memindahkan tugas kecil ke server yang longgar agar waktu selesainya rata sempurna.
            </p>
          </div>
        `;
      },
      renderRightControls(container, v3d) {
        container.innerHTML = `
          <button class="pill-btn primary" id="f-all">Tampilkan Seluruh Partikel</button>
          <button class="pill-btn" id="btn-next-step">Lihat Simulasi Live ➔</button>
        `;
        container.querySelector('#f-all').onclick = () => v3d.setFilterSwarm('all');
        container.querySelector('#btn-next-step').onclick = () => window.SplitDeckApi.next();
      },
      notes: 'Slide 3: Ceritakan 3 pilar ini secara lugas: Langkah 1 mencari calon, Langkah 2 menyaring yang terbaik, dan Langkah 3 memoles keseimbangan server.'
    },

    // -------------------------------------------------------------
    // SLIDE 4: SIMULASI SWARM 3D (INTERAKTIF & JELAS TERLIHAT)
    // -------------------------------------------------------------
    {
      id: 'sim-swarm',
      kicker: 'SIMULASI CARA KERJA 3D',
      title: 'Uji Gerak Kawanan di Ruang 3D',
      lead: 'Perhatikan bagaimana partikel 3D di samping bergerak mencari dasar lembah terendah.',
      mode3d: 'swarm',
      badge3d: 'Live 3D Optimization Surface',
      renderLeft(container) {
        container.innerHTML = `
          <span class="slide-kicker">SIMULASI CARA KERJA 3D</span>
          <h1 class="slide-title">Uji Gerak Kawanan di Ruang 3D</h1>
          <p class="slide-lead">
            Tekan tombol <b>Jalan 1 Langkah</b> atau <b>Auto Play</b> di panel kanan untuk mengamati cara kerja FireBat secara langsung!
          </p>

          <div class="clean-card card-cyan" style="padding:16px 20px;">
            <b style="color:var(--cyan);font-size:17px;">● Partikel Cyan (Kunang-kunang)</b>
            <p style="font-size:14px;color:var(--ink-secondary);margin:4px 0 0;">
              Menyebar luas di seluruh permukaan agar tidak ada calon jadwal yang terlewat.
            </p>
          </div>

          <div class="clean-card card-violet" style="padding:16px 20px;">
            <b style="color:var(--violet);font-size:17px;">● Partikel Violet (Kelelawar)</b>
            <p style="font-size:14px;color:var(--ink-secondary);margin:4px 0 0;">
              Menukik cepat, namun rawan terjebak di lembah-lembah samping jika sendirian.
            </p>
          </div>

          <div class="clean-card card-gold" style="padding:16px 20px;">
            <b style="color:var(--amber);font-size:17px;">★ Partikel Emas (FireBat Hybrid)</b>
            <p style="font-size:14px;color:var(--amber-soft);margin:4px 0 0;">
              Awalnya menyebar (FA), lalu bersatu menukik presisi ke dasar lembah terdalam!
            </p>
          </div>
        `;
      },
      renderRightControls(container, v3d) {
        container.innerHTML = `
          <div style="display:flex;gap:8px;">
            <button class="pill-btn primary" id="btn-step-s4">▶ 1 Langkah</button>
            <button class="pill-btn" id="btn-auto-s4">⚡ Auto Play</button>
            <button class="pill-btn" id="btn-reset-s4">↺ Reset</button>
          </div>
          <span id="s4-status" style="font-family:var(--font-mono);font-size:14px;color:var(--amber);">Iterasi: 0 · Siap</span>
        `;

        let iter = 0;
        let timer = null;
        const statusEl = container.querySelector('#s4-status');

        function doStep() {
          iter++;
          const info = v3d.stepSwarm();
          statusEl.textContent = `Iterasi: ${iter} · ${info ? info.phase : ''}`;
        }

        container.querySelector('#btn-step-s4').onclick = doStep;
        const autoBtn = container.querySelector('#btn-auto-s4');
        autoBtn.onclick = () => {
          if (timer) {
            clearInterval(timer); timer = null; autoBtn.textContent = '⚡ Auto Play';
          } else {
            timer = setInterval(doStep, 160); autoBtn.textContent = '⏸ Jeda';
          }
        };
        container.querySelector('#btn-reset-s4').onclick = () => {
          if (timer) { clearInterval(timer); timer = null; autoBtn.textContent = '⚡ Auto Play'; }
          iter = 0;
          v3d.resetSwarm('rastrigin', Math.floor(Math.random() * 1000));
          statusEl.textContent = 'Iterasi: 0 · Siap';
        };

        return () => { if (timer) clearInterval(timer); };
      },
      notes: 'Slide 4: Di sinilah simulasi cara kerja diuji secara visual. Tunjukkan bahwa pada lanskap 3D bergelombang di samping, kawanan emas FireBat berhasil mendarat di dasar lembah optimum berkat perpaduan eksplorasi dan eksploitasi.'
    },

    // -------------------------------------------------------------
    // SLIDE 5: SIMULASI 3D PEMERATAAN SERVER VM (KOMPARASI LANGSUNG)
    // -------------------------------------------------------------
    {
      id: 'sim-server',
      kicker: 'SIMULASI PENJADWALAN SERVER 3D',
      title: 'Pemerataan 4 Mesin Virtual di 3D',
      lead: 'Pilih algoritma di samping: amati tiang beban server naik-turun dan seimbang di garis emas target!',
      mode3d: 'server',
      badge3d: 'Live 3D Virtual Machines & Target Line',
      renderLeft(container) {
        container.innerHTML = `
          <span class="slide-kicker">SIMULASI PENJADWALAN SERVER 3D</span>
          <h1 class="slide-title">Pemerataan 4 Mesin Virtual di 3D</h1>
          <p class="slide-lead">
            Dataset Minggu 3: 4 VM Heterogen (Small 85 MIPS hingga X-Large 175 MIPS).
          </p>

          <div class="grid-2">
            <div class="clean-card card-gold">
              <div class="stat-label" style="color:var(--amber);">★ FireBat (Hybrid)</div>
              <div class="stat-num" style="color:var(--amber);">14.6s</div>
              <div class="stat-desc"><b>Rata Sempurna (DOI: 0.07)</b> · Beban server selesai bersamaan.</div>
            </div>

            <div class="clean-card card-violet">
              <div class="stat-label" style="color:var(--violet);">Bat Algorithm</div>
              <div class="stat-num" style="color:var(--violet);">15.2s</div>
              <div class="stat-desc">DOI: 0.16 · Ada selisih beban kecil antarmesin.</div>
            </div>

            <div class="clean-card card-cyan">
              <div class="stat-label" style="color:var(--cyan);">Firefly Algorithm</div>
              <div class="stat-num" style="color:var(--cyan);">15.8s</div>
              <div class="stat-desc">DOI: 0.28 · Beban belum merata sepenuhnya.</div>
            </div>

            <div class="clean-card">
              <div class="stat-label" style="color:var(--coral);">Round Robin (Dasar)</div>
              <div class="stat-num" style="color:var(--coral);">21.4s</div>
              <div class="stat-desc">DOI: 0.67 · Server Small kelebihan muatan (merah).</div>
            </div>
          </div>
        `;
      },
      renderRightControls(container, v3d) {
        container.innerHTML = `
          <div style="display:flex;gap:8px;">
            <button class="pill-btn primary" data-a="firebat">★ FireBat</button>
            <button class="pill-btn" data-a="ba">Bat</button>
            <button class="pill-btn" data-a="fa">Firefly</button>
            <button class="pill-btn" data-a="rr">Round Robin</button>
          </div>
          <div id="s5-status" style="font-family:var(--font-mono);font-size:14px;color:var(--amber);">
            Makespan: 14.6s · Sangat Seimbang
          </div>
        `;

        const statEl = container.querySelector('#s5-status');
        const labels = {
          firebat: 'Makespan: 14.6s · Beban Rata Sempurna (DOI: 0.07)',
          ba: 'Makespan: 15.2s · Cukup Rata (DOI: 0.16)',
          fa: 'Makespan: 15.8s · Kurang Rata (DOI: 0.28)',
          rr: 'Makespan: 21.4s · Sangat Timpang (Small VM Merah Overload!)'
        };

        container.querySelectorAll('[data-a]').forEach(btn => {
          btn.onclick = () => {
            container.querySelectorAll('[data-a]').forEach(b => b.classList.remove('primary'));
            btn.classList.add('primary');
            const k = btn.dataset.a;
            v3d.updateServerLoads(k);
            statEl.textContent = labels[k];
          };
        });
      },
      notes: 'Slide 5: Ini simulasi komparasi nyata. Klik Round Robin: lihat tiang server Small melonjak ke 21 detik dan merah. Lalu klik FireBat: lihat 4 tiang server rata sejajar tepat menyentuh garis emas target (14,6 detik)!'
    },

    // -------------------------------------------------------------
    // SLIDE 6: VALIDASI SKALA BESAR (CLOUDSIM 1000 TUGAS)
    // -------------------------------------------------------------
    {
      id: 'validasi-paper',
      kicker: 'VALIDASI JURNAL ILMIAH',
      title: 'Teruji Hingga 1.000 Tugas di CloudSim',
      lead: 'Keunggulan FireBat divalidasi pada simulasi datacenter industri berskala besar.',
      mode3d: 'swarm',
      badge3d: 'CloudSim Benchmark Validation',
      renderLeft(container) {
        container.innerHTML = `
          <span class="slide-kicker">VALIDASI JURNAL ILMIAH</span>
          <h1 class="slide-title">Kinerja Skala Besar di Datacenter</h1>
          <p class="slide-lead">
            Data resmi paper Pathania et al. (Springer Nature, 2026) pada 10 Datacenter &amp; 50 Mesin Virtual:
          </p>

          <div class="clean-card card-gold">
            <div class="stat-label" style="color:var(--amber);">PENGHEMATAN WAKTU MAKESPAN</div>
            <div class="stat-num" style="color:var(--amber);">↓ 50.9%</div>
            <p class="stat-desc">Makespan berkurang hingga separuh dibanding Bat Algorithm murni.</p>
          </div>

          <div class="clean-card card-cyan">
            <div class="stat-label" style="color:var(--cyan);">PENURUNAN KETIMPANGAN SERVER</div>
            <div class="stat-num" style="color:var(--cyan);">↓ 12.7%</div>
            <p class="stat-desc">Degree of Imbalance (DOI) ditekan konsisten pada rentang 200 hingga 1.000 cloudlets.</p>
          </div>

          <div class="clean-card card-violet">
            <div class="stat-label" style="color:var(--violet);">PRODUKTIVITAS SISTEM</div>
            <div class="stat-num" style="color:var(--violet);">↑ 35.0%</div>
            <p class="stat-desc">Throughput tugas per detik melonjak tinggi berkat beban kerja yang terbagi adil.</p>
          </div>
        `;
      },
      renderRightControls(container, v3d) {
        container.innerHTML = `
          <div style="font-size:14px;color:var(--ink-secondary);">
            📈 Teruji pada 200, 400, 600, 800, hingga 1.000 cloudlets.
          </div>
          <button class="pill-btn primary" id="btn-next-step">Ke Kesimpulan ➔</button>
        `;
        container.querySelector('#btn-next-step').onclick = () => window.SplitDeckApi.next();
      },
      notes: 'Tunjukkan ke audiens bahwa simulasi kita sejalan dengan eksperimen CloudSim skala industri di paper Springer Nature 2026.'
    },

    // -------------------------------------------------------------
    // SLIDE 7: KESIMPULAN & REFERENSI
    // -------------------------------------------------------------
    {
      id: 'penutup',
      kicker: 'KESIMPULAN DEMO 1',
      title: 'Ringkasan & Daftar Pustaka',
      lead: 'Seluruh ketentuan tugas minggu 13 telah terpenuhi dengan tuntas.',
      mode3d: 'swarm',
      badge3d: 'Demo 1 Selesai · Menuju Demo 2',
      renderLeft(container) {
        container.innerHTML = `
          <span class="slide-kicker">KESIMPULAN DEMO 1</span>
          <h1 class="slide-title">Siap Melangkah ke Demo 2</h1>

          <div class="clean-card card-gold">
            <div style="font-size:18px;font-weight:700;color:var(--amber);margin-bottom:10px;">3 Poin Kunci Demo 1:</div>
            <ul style="font-size:15px;line-height:1.7;color:var(--ink-primary);padding-left:20px;margin:0;">
              <li><b>Hybrid Terpilih:</b> FireBat menyatukan daya jelajah Firefly dan kecepatan tukik Bat.</li>
              <li><b>Terbukti Lebih Unggul:</b> Mengalahkan Firefly murni dan Bat murni di semua metrik.</li>
              <li><b>Menuju Demo 2 (Minggu 14):</b> Algoritma ini siap diimplementasikan untuk studi kasus dunia nyata.</li>
            </ul>
          </div>

          <div class="clean-card" style="padding:16px 20px;">
            <div style="font-size:13px;font-weight:700;color:var(--ink-secondary);text-transform:uppercase;letter-spacing:0.05em;margin-bottom:8px;">
              Daftar Pustaka Wajib:
            </div>
            <div style="font-size:13px;line-height:1.5;color:var(--ink-secondary);">
              <b>1. Paper Hybrid FireBat:</b> Pathania et al. (2026). <i>FireBat: a hybrid approach for load balancing in cloud computing</i>. Journal of Cloud Computing (Springer Nature).<br/>
              <b>2. Paper Asal Firefly:</b> Yang, X.-S. (2009). <i>Firefly Algorithms for Multimodal Optimization</i>. SAGA 2009, Springer.<br/>
              <b>3. Paper Asal Bat:</b> Yang, X.-S. (2010). <i>A New Metaheuristic Bat-Inspired Algorithm</i>. NICSO 2010, Springer.
            </div>
          </div>
        `;
      },
      renderRightControls(container, v3d) {
        container.innerHTML = `
          <div style="font-size:14px;color:var(--amber);font-weight:700;">
            Terima kasih atas perhatiannya! 🙏
          </div>
          <button class="pill-btn primary" id="btn-replay">↺ Ulang dari Awal</button>
        `;
        container.querySelector('#btn-replay').onclick = () => window.SplitDeckApi.goTo(0);
      },
      notes: 'Tutup presentasi dengan elegan. Seluruh syarat tugas Demo 1 minggu 13 terpenuhi dengan jelas, interaktif, dan mudah dipahami.'
    }
  ];

  global.SplitDeck = SLIDES;
})(window);
