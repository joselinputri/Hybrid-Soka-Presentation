/**
 * Split Application Controller
 * Connects the SplitDeck definition with the dedicated 3D Viewport.
 */
(function (global) {
  'use strict';

  let currentIdx = 0;
  let v3d = null;
  let activeSlideCleanup = null;

  const slides = global.SplitDeck || [];
  const totalSlides = slides.length;

  const deckMain = document.getElementById('deck-main');
  const navDots = document.getElementById('nav-dots');
  const deckCounter = document.getElementById('deck-counter');
  const btnPrev = document.getElementById('btn-prev');
  const btnNext = document.getElementById('btn-next');
  const btnNotes = document.getElementById('btn-notes');
  const btnCloseNotes = document.getElementById('btn-close-notes');
  const notesModal = document.getElementById('notes-modal');
  const notesText = document.getElementById('notes-text');
  const btnFs = document.getElementById('btn-fs');

  // Build the permanent Split DOM layout inside #deck-main
  deckMain.innerHTML = `
    <div class="slide-col" id="slide-col"></div>
    <div class="viewport-3d-stage" id="viewport-stage">
      <div class="viewport-3d-header">
        <span class="viewport-tag">
          <span class="brand-dot"></span>
          <span id="viewport-badge">3D Space</span>
        </span>
        <span style="font-family:var(--font-mono);font-size:12px;color:var(--ink-muted);">
          Drag Mouse / Scroll Zoom
        </span>
      </div>
      <div class="viewport-canvas-box" id="viewport-canvas-box"></div>
      <div class="viewport-3d-footer" id="viewport-footer"></div>
    </div>
  `;

  const slideCol = document.getElementById('slide-col');
  const viewportBadge = document.getElementById('viewport-badge');
  const viewportCanvasBox = document.getElementById('viewport-canvas-box');
  const viewportFooter = document.getElementById('viewport-footer');

  // Initialize 3D Viewport
  if (global.Viewport3D && global.Viewport3D.initViewport3D) {
    v3d = global.Viewport3D.initViewport3D(viewportCanvasBox);
  }

  // Render Navigation Dots
  navDots.innerHTML = '';
  slides.forEach((s, i) => {
    const dot = document.createElement('button');
    dot.className = `dot-btn ${i === 0 ? 'active' : ''}`;
    dot.setAttribute('aria-label', `Slide ${i + 1}`);
    dot.onclick = () => goTo(i);
    navDots.appendChild(dot);
  });

  const api = {
    next,
    prev,
    goTo,
    getCurrentIndex() { return currentIdx; }
  };
  global.SplitDeckApi = api;

  function showSlide(idx) {
    if (idx < 0 || idx >= totalSlides) return;

    if (activeSlideCleanup && typeof activeSlideCleanup === 'function') {
      try { activeSlideCleanup(); } catch (e) { console.warn(e); }
      activeSlideCleanup = null;
    }

    currentIdx = idx;
    const slide = slides[idx];

    // Update Dots
    Array.from(navDots.children).forEach((dot, i) => {
      dot.classList.toggle('active', i === idx);
    });

    // Update Counter & Arrow states
    deckCounter.textContent = `${String(idx + 1).padStart(2, '0')} / ${String(totalSlides).padStart(2, '0')}`;
    btnPrev.disabled = (idx === 0);
    btnNext.disabled = (idx === totalSlides - 1);

    // Update 3D Mode & Badge
    if (viewportBadge) {
      viewportBadge.textContent = slide.badge3d || '3D Interactive';
    }
    if (v3d) {
      v3d.setMode(slide.mode3d || 'swarm');
    }

    // Render Left Slide Content
    if (slideCol && typeof slide.renderLeft === 'function') {
      slide.renderLeft(slideCol, api);
    }

    // Render Right Viewport Controls
    if (viewportFooter && typeof slide.renderRightControls === 'function') {
      activeSlideCleanup = slide.renderRightControls(viewportFooter, v3d);
    } else if (viewportFooter) {
      viewportFooter.innerHTML = '';
    }

    // Update Speaker Notes
    if (notesText) {
      notesText.textContent = slide.notes || 'Fokus pada demonstrasi interaktif di layar.';
    }

    // Ensure 3D Canvas resizes properly to container
    if (v3d && typeof v3d.resize === 'function') {
      setTimeout(() => v3d.resize(), 50);
    }
  }

  function next() {
    if (currentIdx < totalSlides - 1) {
      showSlide(currentIdx + 1);
    }
  }

  function prev() {
    if (currentIdx > 0) {
      showSlide(currentIdx - 1);
    }
  }

  function goTo(idx) {
    showSlide(idx);
  }

  // Event Listeners
  btnPrev.onclick = prev;
  btnNext.onclick = next;

  // Keyboard Navigation
  window.addEventListener('keydown', (e) => {
    // Avoid interfering if user is in an input or textarea
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;

    if (e.key === 'ArrowRight' || e.key === ' ' || e.key === 'PageDown') {
      e.preventDefault();
      next();
    } else if (e.key === 'ArrowLeft' || e.key === 'PageUp') {
      e.preventDefault();
      prev();
    } else if (e.key >= '1' && e.key <= '7') {
      const targetSlide = parseInt(e.key, 10) - 1;
      if (targetSlide < totalSlides) {
        goTo(targetSlide);
      }
    } else if (e.key === 'n' || e.key === 'N') {
      toggleNotes();
    } else if (e.key === 'f' || e.key === 'F') {
      toggleFullscreen();
    }
  });

  // Speaker Notes
  function toggleNotes() {
    notesModal.classList.toggle('hidden');
  }
  btnNotes.onclick = toggleNotes;
  btnCloseNotes.onclick = () => notesModal.classList.add('hidden');

  // Fullscreen
  function toggleFullscreen() {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
      }
    }
  }
  btnFs.onclick = toggleFullscreen;

  // Initialize first slide
  showSlide(0);

})(window);
