/**
 * Dedicated 3D Viewport Engine
 * Renders cleanly inside the designated right viewport canvas container.
 * Features:
 * - 3D Landscape Surface (Wireframe mesh + color gradient)
 * - Animated 3D Swarms (FA cyan, BA violet, FireBat gold)
 * - 4 Server Monoliths with live load bars
 * - Full OrbitControls with intuitive mouse interaction
 */
(function (global) {
  'use strict';

  function initViewport3D(container) {
    let width = container.clientWidth || 600;
    let height = container.clientHeight || 450;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x040817);

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 7.5, 12);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.maxPolarAngle = Math.PI / 2.05;
    controls.minDistance = 3;
    controls.maxDistance = 35;
    controls.target.set(0, 0.5, 0);

    // Lights
    scene.add(new THREE.AmbientLight(0xffffff, 0.6));
    const dirLight = new THREE.DirectionalLight(0xffffff, 0.9);
    dirLight.position.set(8, 14, 10);
    scene.add(dirLight);

    const lightGold = new THREE.PointLight(0xfbbf24, 1.6, 25);
    lightGold.position.set(4, 6, 2);
    scene.add(lightGold);

    // 1. 3D Optimization Surface (Rastrigin, Sphere, Ackley)
    const landGroup = new THREE.Group();
    scene.add(landGroup);

    let terrainMesh = null;
    function buildSurface(landKey = 'rastrigin') {
      if (terrainMesh) landGroup.remove(terrainMesh);
      const land = global.SimEngine.LANDSCAPES[landKey] || global.SimEngine.LANDSCAPES.rastrigin;
      const R = land.range;
      const segs = 36;
      const geo = new THREE.PlaneGeometry(16, 16, segs, segs);
      geo.rotateX(-Math.PI / 2);

      const pos = geo.attributes.position;
      const colors = [];
      const colHelper = new THREE.Color();
      let minY = Infinity, maxY = -Infinity;

      for (let i = 0; i < pos.count; i++) {
        const x = (pos.getX(i) / 8) * R;
        const z = (pos.getZ(i) / 8) * R;
        const v = land.fn(x, z);
        pos.setY(i, v * 0.12 - 0.5);
        if (v < minY) minY = v;
        if (v > maxY) maxY = v;
      }
      pos.needsUpdate = true;
      geo.computeVertexNormals();

      for (let i = 0; i < pos.count; i++) {
        const h = (pos.getY(i) + 0.5) / 0.12;
        const ratio = Math.pow((h - minY) / Math.max(1e-5, maxY - minY), 0.6);
        colHelper.setHSL(0.58 - ratio * 0.45, 0.85, 0.28 + ratio * 0.35);
        colors.push(colHelper.r, colHelper.g, colHelper.b);
      }
      geo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));

      const mat = new THREE.MeshStandardMaterial({
        vertexColors: true,
        wireframe: true,
        roughness: 0.6,
        metalness: 0.2
      });
      terrainMesh = new THREE.Mesh(geo, mat);
      landGroup.add(terrainMesh);
    }
    buildSurface('rastrigin');

    // 2. Swarm Particles
    const swarmGroup = new THREE.Group();
    scene.add(swarmGroup);

    const sGeo = new THREE.SphereGeometry(0.25, 12, 12);
    function makeParticles(hex, count, scale = 1.0) {
      const g = new THREE.Group();
      const mat = new THREE.MeshStandardMaterial({ color: hex, emissive: hex, emissiveIntensity: 0.7 });
      for (let i = 0; i < count; i++) {
        const m = new THREE.Mesh(sGeo, mat);
        m.scale.setScalar(scale);
        g.add(m);
      }
      return g;
    }

    const meshFA = makeParticles(0x38bdf8, 16, 0.9);   // Cyan Kunang-kunang
    const meshBA = makeParticles(0xa855f7, 16, 0.9);   // Violet Kelelawar
    const meshFB = makeParticles(0xfbbf24, 16, 1.35);  // Emas FireBat
    swarmGroup.add(meshFA);
    swarmGroup.add(meshBA);
    swarmGroup.add(meshFB);

    let swarmManager = global.SimEngine.create3DSwarm('rastrigin', 101);

    function syncSwarmMeshes() {
      const R = swarmManager.land.range;
      function sync(group, list) {
        for (let i = 0; i < list.length && i < group.children.length; i++) {
          const p = list[i];
          const m = group.children[i];
          const wx = (p.x / R) * 8;
          const wz = (p.z / R) * 8;
          m.position.set(wx, p.y * 0.12 - 0.2, wz);
        }
      }
      sync(meshFA, swarmManager.fireflies);
      sync(meshBA, swarmManager.bats);
      sync(meshFB, swarmManager.firebat);
    }
    syncSwarmMeshes();

    // 3. 4 Server Monoliths with Live 3D Gantt Blocks
    const serverGroup = new THREE.Group();
    serverGroup.position.set(0, -0.6, 0);
    scene.add(serverGroup);

    const vmConfigs = [
      { name: 'VM-1 (Small)', mips: 85, color: 0xf87171, x: -4.5 },
      { name: 'VM-2 (Medium)', mips: 115, color: 0xfbbf24, x: -1.5 },
      { name: 'VM-3 (Large)', mips: 145, color: 0x38bdf8, x: 1.5 },
      { name: 'VM-4 (X-Large)', mips: 175, color: 0x4ade80, x: 4.5 }
    ];

    const serverPillars = [];
    vmConfigs.forEach((cfg) => {
      const g = new THREE.Group();
      g.position.set(cfg.x, 0, 0);

      // Pedestal
      const base = new THREE.Mesh(
        new THREE.CylinderGeometry(0.9, 1.0, 0.4, 24),
        new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.3, metalness: 0.8 })
      );
      base.position.y = 0.2;
      g.add(base);

      // Load pillar
      const loadBar = new THREE.Mesh(
        new THREE.BoxGeometry(1.0, 1, 1.0),
        new THREE.MeshStandardMaterial({ color: cfg.color, emissive: cfg.color, emissiveIntensity: 0.4 })
      );
      loadBar.position.y = 0.5;
      g.add(loadBar);

      // Top glowing ring
      const ring = new THREE.Mesh(
        new THREE.RingGeometry(1.05, 1.15, 24),
        new THREE.MeshBasicMaterial({ color: cfg.color, side: THREE.DoubleSide })
      );
      ring.rotation.x = -Math.PI / 2;
      ring.position.y = 0.41;
      g.add(ring);

      serverGroup.add(g);
      serverPillars.push({ group: g, loadBar, cfg });
    });

    // Golden Makespan Line
    const targetLineGeo = new THREE.BoxGeometry(12, 0.05, 0.05);
    const targetLineMat = new THREE.MeshBasicMaterial({ color: 0xfbbf24 });
    const targetLineMesh = new THREE.Mesh(targetLineGeo, targetLineMat);
    targetLineMesh.position.set(0, 3.2, 0);
    serverGroup.add(targetLineMesh);

    // Initial Modes
    serverGroup.visible = false;
    swarmGroup.visible = true;
    landGroup.visible = true;

    const ALGO_LOADS = {
      firebat: [14.1, 14.4, 14.6, 14.2],
      ba:      [15.2, 13.8, 14.0, 15.1],
      fa:      [15.8, 12.5, 13.2, 15.7],
      rr:      [21.4, 17.2, 14.1, 12.8]
    };

    function updateServerLoads(algoKey) {
      const loads = ALGO_LOADS[algoKey] || ALGO_LOADS.firebat;
      const mk = Math.max(...loads);
      const scaleH = 0.24;

      serverPillars.forEach((p, idx) => {
        const val = loads[idx];
        const h = Math.max(0.2, val * scaleH);
        p.loadBar.scale.set(1, h, 1);
        p.loadBar.position.y = 0.4 + h / 2;

        if (val > 17) {
          p.loadBar.material.color.setHex(0xf43f5e);
          p.loadBar.material.emissive.setHex(0xf43f5e);
        } else {
          p.loadBar.material.color.setHex(p.cfg.color);
          p.loadBar.material.emissive.setHex(p.cfg.color);
        }
      });

      targetLineMesh.position.y = 0.4 + mk * scaleH;
    }
    updateServerLoads('firebat');

    function setMode(mode) {
      // mode: 'swarm' (Slide 1-4, 6-7) or 'server' (Slide 5)
      if (mode === 'server') {
        serverGroup.visible = true;
        swarmGroup.visible = false;
        landGroup.visible = false;
        camera.position.set(0, 3.8, 10.5);
        controls.target.set(0, 1.8, 0);
      } else {
        serverGroup.visible = false;
        swarmGroup.visible = true;
        landGroup.visible = true;
        camera.position.set(0, 7.5, 12);
        controls.target.set(0, 0.5, 0);
      }
    }

    let animId = null;
    function animate() {
      animId = requestAnimationFrame(animate);
      controls.update();

      // Subtle slow rotation of surface when in swarm mode
      if (landGroup.visible) {
        landGroup.rotation.y += 0.0015;
        swarmGroup.rotation.y += 0.0015;
      }

      renderer.render(scene, camera);
    }
    animate();

    function resize() {
      width = container.clientWidth;
      height = container.clientHeight;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    }
    window.addEventListener('resize', resize);

    return {
      setMode,
      buildSurface,
      stepSwarm() {
        const res = swarmManager.step();
        syncSwarmMeshes();
        return res;
      },
      resetSwarm(landKey, seed) {
        swarmManager = global.SimEngine.create3DSwarm(landKey, seed);
        buildSurface(landKey);
        syncSwarmMeshes();
      },
      setFilterSwarm(type) {
        meshFA.visible = (type === 'all' || type === 'fa');
        meshBA.visible = (type === 'all' || type === 'ba');
        meshFB.visible = (type === 'all' || type === 'firebat');
      },
      updateServerLoads,
      resize,
      destroy() {
        window.removeEventListener('resize', resize);
        cancelAnimationFrame(animId);
        renderer.dispose();
      }
    };
  }

  global.Viewport3D = {
    initViewport3D
  };
})(window);
