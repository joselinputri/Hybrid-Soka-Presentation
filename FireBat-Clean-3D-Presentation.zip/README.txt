PRESENTASI DEMO 1 (MINGGU 13) — FIREBAT HYBRID (FIREFLY x BAT)
========================================================================

PETUNJUK MEMBUKA:
1. Ekstrak file zip ini.
2. Klik dua kali "index.html" untuk langsung membuka di browser (Chrome / Edge / Firefox).
   Semua library 3D (Three.js dan OrbitControls) sudah disertakan secara offline di folder lib/.

FITUR UTAMA:
- Fokus pada 1 hybrid unggul terpilih: FireBat (Hybrid Firefly + Bat).
- Konsep dasar mudah dipahami, tidak rumit teknis.
- Simulasi Interaktif 3D:
  * Slide 4: Simulasi 3D Permukaan Lanskap (Rastrigin, Sphere, Ackley) dengan kawanan partikel 3D (Cyan, Violet, Emas). Kamera 3D bisa diputar bebas (OrbitControls).
  * Slide 5: Simulasi 3D Rak Server Datacenter (4 VM) menunjukkan pemerataan beban virtual machine.
- Perbandingan langsung dengan metode sebelumnya (Firefly dan Bat).
- Validasi data dari paper ilmiah: Pathania et al. (Springer Nature, 2026).

PINTASAN KEYBOARD:
- Spasi / Panah Kanan : Slide berikutnya
- Panah Kiri          : Slide sebelumnya
- Angka 1-8           : Lompat langsung ke slide tertentu
- N                   : Buka / tutup Catatan Presenter
- F                   : Mode Layar Penuh (Fullscreen)
