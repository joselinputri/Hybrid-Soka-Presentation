/**
 * 3D Ambient Background Engine
 * Sleek, abstract, high-tech aesthetic:
 * - Dynamic undulating wireframe waves (representing the continuous search space)
 * - Orbiting glowing nodes (Cyan for Firefly, Violet for Bat, Golden pulse for FireBat)
 * - 4 floating crystalline monoliths in the distance representing the 4 VMs
 * - Camera gracefully travels and pivots based on active slide
 */
(function (global) {
  'use strict';

  function initBackground3D(container) {
    let width = container.clientWidth || window.innerWidth;
    let height = container.clientHeight || window.innerHeight;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x040817);
    scene.fog = new THREE.FogExp2(0x040817, 0.022);

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 5, 14);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Subtle Ambient & Accent Spotlights
    scene.add(new THREE.AmbientLight(0xffffff, 0.35));

    const lightGold = new THREE.PointLight(0xfbbf24, 1.8, 30);
    lightGold.position.set(6, 8, 4);
    scene.add(lightGold);

    const lightCyan = new THREE.PointLight(0x38bdf8, 1.5, 30);
    lightCyan.position.set(-6, 6, 2);
    scene.add(lightCyan);

    const lightViolet = new THREE.PointLight(0xa855f7, 1.2, 25);
    lightViolet.position.set(0, 4, -4);
    scene.add(lightViolet);

    // 1. Sleek Undulating Grid Floor (Abstract Metaheuristic Landscape)
    const gridRows = 50, gridCols = 50;
    const gridGeo = new THREE.PlaneGeometry(36, 36, gridCols, gridRows);
    gridGeo.rotateX(-Math.PI / 2);

    const gridMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      wireframe: true,
      roughness: 0.5,
      metalness: 0.8
    });
    const gridMesh = new THREE.Mesh(gridGeo, gridMat);
    gridMesh.position.y = -1.5;
    scene.add(gridMesh);

    // 2. Swarm Particles (Abstract Floating Energy Orbs)
    const particleCount = 45;
    const particlesGroup = new THREE.Group();
    const sphereGeo = new THREE.SphereGeometry(0.09, 8, 8);

    const particles = [];
    for (let i = 0; i < particleCount; i++) {
      let colorHex = 0x38bdf8; // Firefly Cyan
      if (i % 3 === 1) colorHex = 0xa855f7; // Bat Violet
      if (i % 3 === 2) colorHex = 0xfbbf24; // FireBat Gold

      const mat = new THREE.MeshBasicMaterial({ color: colorHex });
      const mesh = new THREE.Mesh(sphereGeo, mat);

      const angle = Math.random() * Math.PI * 2;
      const radius = 2.5 + Math.random() * 5.5;
      mesh.position.set(
        Math.cos(angle) * radius,
        (Math.random() - 0.2) * 3,
        Math.sin(angle) * radius - 2
      );

      particlesGroup.add(mesh);
      particles.push({
        mesh,
        angle,
        radius,
        speed: (0.003 + Math.random() * 0.007) * (Math.random() > 0.5 ? 1 : -1),
        baseY: mesh.position.y,
        floatSpeed: 0.001 + Math.random() * 0.003
      });
    }
    scene.add(particlesGroup);

    // 3. Four Sleek Monoliths (Minimalist VM Stations in the distance)
    const monoliths = [];
    const vmCols = [0xf87171, 0xfbbf24, 0x38bdf8, 0x4ade80];
    const mWidth = 1.0;
    for (let i = 0; i < 4; i++) {
      const g = new THREE.Group();
      g.position.set(-4.5 + i * 3.0, -1.5, -4);

      // Crystalline pillar
      const pillar = new THREE.Mesh(
        new THREE.BoxGeometry(mWidth, 4.0, mWidth),
        new THREE.MeshStandardMaterial({
          color: 0x0f172a,
          metalness: 0.9,
          roughness: 0.2,
          transparent: true,
          opacity: 0.9
        })
      );
      pillar.position.y = 2.0;
      g.add(pillar);

      // Glowing edge line
      const edge = new THREE.Mesh(
        new THREE.BoxGeometry(mWidth * 1.02, 0.06, mWidth * 1.02),
        new THREE.MeshBasicMaterial({ color: vmCols[i] })
      );
      edge.position.y = 3.9;
      g.add(edge);

      // Floating light core
      const core = new THREE.Mesh(
        new THREE.OctahedronGeometry(0.22, 0),
        new THREE.MeshBasicMaterial({ color: vmCols[i], wireframe: true })
      );
      core.position.y = 4.6;
      g.add(core);

      scene.add(g);
      monoliths.push({ group: g, core, col: vmCols[i] });
    }

    // Camera viewpoints for each slide index (0 to 6)
    const CAMERA_DESTS = [
      { pos: [0, 3.5, 12], rot: [-0.15, 0, 0] },         // Cover: cinematic wide
      { pos: [-3, 2.8, 10], rot: [-0.08, 0.12, 0] },     // Dilema / Masalah: tilt left
      { pos: [2.5, 3.0, 9.5], rot: [-0.1, -0.15, 0] },   // 3 Pilar FireBat: tilt right
      { pos: [0, 4.8, 8.5], rot: [-0.28, 0, 0] },        // Topologi Ruang Pencarian: looking downward
      { pos: [0, 1.8, 7.5], rot: [0.04, 0, 0] },         // Server Load Balance: close to monoliths
      { pos: [-1.8, 2.5, 9], rot: [-0.05, 0.08, 0] },    // Perbandingan 10 Beban: angled view
      { pos: [0, 3.5, 12], rot: [-0.15, 0, 0] }          // Penutup: wide reset
    ];

    let targetCamPos = new THREE.Vector3(0, 3.5, 12);
    let targetCamRot = new THREE.Vector3(-0.15, 0, 0);
    let animId = null;
    let clock = new THREE.Clock();

    function setSlideIndex(idx) {
      const dest = CAMERA_DESTS[idx] || CAMERA_DESTS[0];
      targetCamPos.set(dest.pos[0], dest.pos[1], dest.pos[2]);
      targetCamRot.set(dest.rot[0], dest.rot[1], dest.rot[2]);
    }

    // Dynamic wave animation on floor
    const posAttr = gridGeo.attributes.position;
    const initialY = new Float32Array(posAttr.count);
    for (let i = 0; i < posAttr.count; i++) initialY[i] = posAttr.getY(i);

    function animate() {
      animId = requestAnimationFrame(animate);
      const time = clock.getElapsedTime();

      // Smooth camera interpolation
      camera.position.lerp(targetCamPos, 0.045);
      camera.rotation.x += (targetCamRot.x - camera.rotation.x) * 0.045;
      camera.rotation.y += (targetCamRot.y - camera.rotation.y) * 0.045;

      // Animate ground waves
      for (let i = 0; i < posAttr.count; i++) {
        const x = posAttr.getX(i);
        const z = posAttr.getZ(i);
        const wave = Math.sin(x * 0.45 + time * 1.2) * Math.cos(z * 0.45 + time * 1.0) * 0.45;
        posAttr.setY(i, initialY[i] + wave);
      }
      posAttr.needsUpdate = true;

      // Orbit particles
      particles.forEach((p) => {
        p.angle += p.speed;
        p.mesh.position.x = Math.cos(p.angle) * p.radius;
        p.mesh.position.z = Math.sin(p.angle) * p.radius - 2;
        p.mesh.position.y = p.baseY + Math.sin(time * 2 + p.angle) * 0.35;
      });

      // Monolith cores floating rotation
      monoliths.forEach((m, i) => {
        m.core.rotation.y += 0.015;
        m.core.rotation.x += 0.008;
        m.core.position.y = 4.6 + Math.sin(time * 2.5 + i) * 0.12;
      });

      renderer.render(scene, camera);
    }

    function resize() {
      width = container.clientWidth;
      height = container.clientHeight;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    }

    window.addEventListener('resize', resize);
    animate();

    return {
      setSlideIndex,
      destroy() {
        window.removeEventListener('resize', resize);
        cancelAnimationFrame(animId);
        renderer.dispose();
      }
    };
  }

  global.Background3D = {
    initBackground3D
  };
})(window);
