/**
 * Clean-Look Slide Deck
 * 7 Straightforward, high-impact slides:
 * 1. Title / Vision
 * 2. The Dilemma (Firefly vs Bat)
 * 3. The Solution: FireBat (3 Simple Pillars)
 * 4. Topology of Optimization (Why exploration + exploitation works)
 * 5. Balanced Virtual Machines (Live Cloud Data)
 * 6. Proven Performance (CloudSim 1,000 Tasks)
 * 7. Summary & Academic Citation
 */
(function (global) {
  'use strict';

  const SLIDES = [
    // -------------------------------------------------------------
    // SLIDE 1: COVER
    // -------------------------------------------------------------
    {
      id: 'cover',
      kicker: 'TUGAS MINGGU 13 · DEMO 1',
      title: 'FireBat: Sinergi Cerdas Dua Algoritma',
      lead: 'Menjawab dilema penjadwalan tugas di Cloud melalui penggabungan metaheuristik Firefly dan Bat.',
      render(container, api) {
        container.innerHTML = `
          <div class="slide">
            <span class="slide-kicker">TUGAS MINGGU 13 · DEMO 1</span>
            <h1 class="slide-title">
              FireBat: Sinergi Cerdas<br/>
              <span style="background:linear-gradient(135deg, #38bdf8 0%, #fbbf24 50%, #a855f7 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">
                Firefly × Bat Algorithm
              </span>
            </h1>
            <p class="slide-lead">
              Pola hybrid metaheuristik + metaheuristik untuk mencapai pembagian beban server yang rata sempurna dan waktu eksekusi paling cepat.
            </p>
            <div class="grid-3" style="max-width:960px;">
              <div class="clean-card card-cyan">
                <div class="stat-label">Sumber Ilmiah</div>
                <div style="font-size:22px;font-weight:700;margin:6px 0;color:var(--cyan);">Springer Nature</div>
                <div class="stat-desc">Journal of Cloud Computing (2026)</div>
              </div>
              <div class="clean-card card-gold">
                <div class="stat-label">Algoritma Terpilih</div>
                <div style="font-size:22px;font-weight:700;margin:6px 0;color:var(--amber);">FireBat</div>
                <div class="stat-desc">Kombinasi FA (Eksplorasi) + BA (Eksploitasi)</div>
              </div>
              <div class="clean-card card-violet">
                <div class="stat-label">Metode Pembanding</div>
                <div style="font-size:22px;font-weight:700;margin:6px 0;color:var(--violet);">FA &amp; BA Murni</div>
                <div class="stat-desc">2 Metode dari presentasi sebelumnya</div>
              </div>
            </div>
            <div class="action-row">
              <button class="pill-btn primary" id="btn-start">Mulai Presentasi ➔</button>
            </div>
          </div>
        `;
        container.querySelector('#btn-start').onclick = () => api.next();
      },
      notes: 'Buka presentasi dengan tenang. Sampaikan bahwa pada tugas minggu 13 demo 1 ini, kita memilih 1 algoritma hybrid unggul dari jurnal ilmiah Springer Nature (2026) bernama FireBat, yang menyempurnakan Firefly dan Bat dari tugas sebelumnya.'
    },

    // -------------------------------------------------------------
    // SLIDE 2: DILEMA FIREFLY VS BAT
    // -------------------------------------------------------------
    {
      id: 'dilema',
      kicker: 'LATAR BELAKANG',
      title: 'Dilema Dua Algoritma Sebelumnya',
      lead: 'Mengapa metaheuristik tunggal masih sering gagal menyeimbangkan server cloud?',
      render(container) {
        container.innerHTML = `
          <div class="slide">
            <span class="slide-kicker">LATAR BELAKANG</span>
            <h1 class="slide-title">Dilema Dua Metode Sebelumnya</h1>
            <p class="slide-lead">
              Firefly jago mencari jalan tapi lambat, sedangkan Bat cepat menukik tapi mudah terjebak.
            </p>
            <div class="grid-2">
              <div class="clean-card card-cyan">
                <div style="display:flex;justify-content:space-between;align-items:center;">
                  <span class="stat-label" style="color:var(--cyan);">Metode Sebelumnya #1</span>
                  <span style="font-family:var(--font-mono);font-size:14px;color:var(--cyan);">FA</span>
                </div>
                <div class="stat-num" style="color:var(--cyan);">Firefly</div>
                <div style="font-size:19px;font-weight:700;margin-bottom:8px;">Kelebihan: Eksplorasi Global Luas</div>
                <p style="color:var(--ink-secondary);font-size:17px;line-height:1.5;margin:0 0 12px;">
                  Terinspirasi dari cahaya kunang-kunang. Sangat teliti menyusuri seluruh ruang solusi agar tidak ada calon jadwal yang terlewat.
                </p>
                <div style="padding:10px 14px;border-radius:12px;background:rgba(244,63,94,0.12);border:1px solid rgba(244,63,94,0.3);color:var(--coral);font-size:15px;font-weight:600;">
                  ✗ Celah: Lambat sekali mengerucut (konvergensi) di iterasi akhir.
                </div>
              </div>

              <div class="clean-card card-violet">
                <div style="display:flex;justify-content:space-between;align-items:center;">
                  <span class="stat-label" style="color:var(--violet);">Metode Sebelumnya #2</span>
                  <span style="font-family:var(--font-mono);font-size:14px;color:var(--violet);">BA</span>
                </div>
                <div class="stat-num" style="color:var(--violet);">Bat Algorithm</div>
                <div style="font-size:19px;font-weight:700;margin-bottom:8px;">Kelebihan: Eksploitasi Menukik Tajam</div>
                <p style="color:var(--ink-secondary);font-size:17px;line-height:1.5;margin:0 0 12px;">
                  Terinspirasi dari sonar ekolokasi kelelawar. Melesat sangat kencang langsung menuju target terbaik yang terdeteksi.
                </p>
                <div style="padding:10px 14px;border-radius:12px;background:rgba(244,63,94,0.12);border:1px solid rgba(244,63,94,0.3);color:var(--coral);font-size:15px;font-weight:600;">
                  ✗ Celah: Mudah tertipu dan terjebak di lembah lokal (local optimum).
                </div>
              </div>
            </div>
          </div>
        `;
      },
      notes: 'Tunjukkan dua sisi mata uang: Kunang-kunang punya mata yang awas mencari ke mana-mana tapi jalannya lambat. Kelelawar terbang sangat cepat tapi sonarnya bisa menabrak tebing jika titik awalnya salah. Solusinya adalah menyatukan keduanya.'
    },

    // -------------------------------------------------------------
    // SLIDE 3: 3 PILAR FIREBAT
    // -------------------------------------------------------------
    {
      id: 'pilar',
      kicker: 'CARA KERJA SEDERHANA',
      title: 'Tiga Pilar Solusi FireBat',
      lead: 'Bagaimana FireBat bekerja menuntaskan kelemahan kedua metode pendahulunya?',
      render(container) {
        container.innerHTML = `
          <div class="slide">
            <span class="slide-kicker">CARA KERJA SEDERHANA</span>
            <h1 class="slide-title">Tiga Pilar Solusi FireBat</h1>
            <p class="slide-lead">
              Eksplorasi ganda di awal, seleksi bibit unggul, lalu polesan akhir penyeimbang server.
            </p>
            <div class="grid-3">
              <div class="clean-card card-cyan">
                <div class="stat-label">Tahap 1</div>
                <div class="stat-num" style="color:var(--cyan);font-size:42px;">Populasi Ganda</div>
                <p style="font-size:17px;color:var(--ink-secondary);line-height:1.5;margin:0;">
                  Kawanan dibagi dua: regu Kunang-kunang memetakan calon jadwal potensial, sedangkan regu Kelelawar menguji kekuatan titik awal secara paralel.
                </p>
              </div>

              <div class="clean-card card-gold">
                <div class="stat-label">Tahap 2</div>
                <div class="stat-num" style="color:var(--amber);font-size:42px;">Kolam Elit</div>
                <p style="font-size:17px;color:var(--ink-secondary);line-height:1.5;margin:0;">
                  Hasil terbaik kedua regu digabungkan (<i>Hybrid Elite Pool</i>). Jadwal yang paling cepat dan seimbang dipilih untuk babak final.
                </p>
              </div>

              <div class="clean-card card-violet">
                <div class="stat-label">Tahap 3</div>
                <div class="stat-num" style="color:var(--violet);font-size:42px;">Migrasi Beban</div>
                <p style="font-size:17px;color:var(--ink-secondary);line-height:1.5;margin:0;">
                  Algoritma Bat menukik memoles jadwal. Jika ada server yang masih sedikit kelebihan tugas, sistem memindahkan tugas kecil ke server yang longgar.
                </p>
              </div>
            </div>
          </div>
        `;
      },
      notes: 'Jelaskan 3 langkah ini dengan santai dan tanpa rumus rumit: Langkah 1 mencari secara paralel, Langkah 2 menyaring calon terbaik ke meja rapat, dan Langkah 3 memoles serta menyeimbangkan tugas agar server selesai bersamaan.'
    },

    // -------------------------------------------------------------
    // SLIDE 4: PEMETAAN RUANG PENCARIAN (VISUAL TOPOLOGI)
    // -------------------------------------------------------------
    {
      id: 'topologi',
      kicker: 'INTUISI RUANG PENCARIAN',
      title: 'Menembus Lembah-Lembah Solusi',
      lead: 'Perhatikan gelombang 3D di latar belakang: begitulah gambaran ruang optimasi penjadwalan cloud.',
      render(container) {
        container.innerHTML = `
          <div class="slide">
            <span class="slide-kicker">INTUISI RUANG PENCARIAN</span>
            <h1 class="slide-title">Menembus Lembah Solusi Cloud</h1>
            <p class="slide-lead">
              Gelombang kawat 3D di belakang Anda merepresentasikan kombinasi penugasan tugas ke server.
            </p>
            <div class="grid-3">
              <div class="clean-card">
                <div style="font-size:14px;color:var(--cyan);font-weight:700;">PARTIKEL CYAN</div>
                <div style="font-size:24px;font-weight:800;margin:6px 0;">Menjelajah Luas</div>
                <p style="font-size:16px;color:var(--ink-secondary);margin:0;">
                  Mencegah sistem langsung terjebak di lembah dangkal pertama yang ditemukan.
                </p>
              </div>

              <div class="clean-card">
                <div style="font-size:14px;color:var(--violet);font-weight:700;">PARTIKEL VIOLET</div>
                <div style="font-size:24px;font-weight:800;margin:6px 0;">Menukik Cepat</div>
                <p style="font-size:16px;color:var(--ink-secondary);margin:0;">
                  Mempercepat waktu pencarian ribuan kali lipat dibanding pencarian acak biasa.
                </p>
              </div>

              <div class="clean-card card-gold">
                <div style="font-size:14px;color:var(--amber);font-weight:700;">PARTIKEL EMAS (FIREBAT)</div>
                <div style="font-size:24px;font-weight:800;margin:6px 0;color:var(--amber);">Presisi 100%</div>
                <p style="font-size:16px;color:var(--amber-soft);margin:0;">
                  Menemukan dasar lembah paling optimal: waktu selesai minimum dan beban server paling adil.
                </p>
              </div>
            </div>
          </div>
        `;
      },
      notes: 'Ajak audiens melihat latar belakang 3D yang sedang bergelombang halus. Katakan: Gelombang ini adalah simulasi permukaan matematika pencarian tugas. Partikel emas FireBat adalah yang selalu sukses menukik ke lembah paling dalam tanpa tersangkut di tebing bukit.'
    },

    // -------------------------------------------------------------
    // SLIDE 5: HASIL SERVER NYATA (DATASET MINGGU 3)
    // -------------------------------------------------------------
    {
      id: 'server-data',
      kicker: 'HASIL EKSPERIMEN MINGGU 3',
      title: 'Pemerataan Beban di 4 Mesin Virtual',
      lead: 'Perbandingan nyata waktu penyelesaian tugas (Makespan) dan pemerataan server.',
      render(container) {
        container.innerHTML = `
          <div class="slide">
            <span class="slide-kicker">HASIL EKSPERIMEN MINGGU 3</span>
            <h1 class="slide-title">Server Rata Sempurna, Beban Merata</h1>
            <p class="slide-lead">
              Uji coba 20 tugas acak pada 4 Mesin Virtual heterogen (Small 85 MIPS hingga X-Large 175 MIPS).
            </p>
            <div class="grid-4">
              <div class="clean-card card-gold">
                <div class="stat-label" style="color:var(--amber);">★ FireBat (Hybrid)</div>
                <div class="stat-num" style="color:var(--amber);">14.6s</div>
                <div class="stat-desc"><b>Tercepat</b> · Selisih cuma +2.5% dari batas ideal teoretis.</div>
              </div>

              <div class="clean-card card-violet">
                <div class="stat-label" style="color:var(--violet);">Bat Algorithm</div>
                <div class="stat-num" style="color:var(--violet);">15.2s</div>
                <div class="stat-desc">Lebih lambat 4.1% · Ada sedikit ketimpangan beban.</div>
              </div>

              <div class="clean-card card-cyan">
                <div class="stat-label" style="color:var(--cyan);">Firefly Algorithm</div>
                <div class="stat-num" style="color:var(--cyan);">15.8s</div>
                <div class="stat-desc">Lebih lambat 8.2% · Belum konvergen maksimal.</div>
              </div>

              <div class="clean-card">
                <div class="stat-label" style="color:var(--coral);">Round Robin (Dasar)</div>
                <div class="stat-num" style="color:var(--coral);">21.4s</div>
                <div class="stat-desc">Sangat lambat (+46%) · Server Small kelebihan muatan.</div>
              </div>
            </div>
            <div style="margin-top:24px;padding:16px 24px;border-radius:16px;background:rgba(251,191,36,0.1);border:1px solid rgba(251,191,36,0.3);font-size:18px;">
              ⚡ <b>Indikator Ketimpangan (DOI):</b> FireBat meraih <b>0.071</b> (sangat seimbang) vs Bat <b>0.165</b> dan Firefly <b>0.284</b>.
            </div>
          </div>
        `;
      },
      notes: 'Tunjukkan angka-angka besar yang tegas di layar: FireBat menyelesaikan semua tugas dalam 14,6 detik, hampir menyamai batas kecepatan ideal teoretis (14,2 detik), sementara metode lain tertinggal di atas 15 detik.'
    },

    // -------------------------------------------------------------
    // SLIDE 6: VALIDASI SKALA BESAR (CLOUDSIM 1000 TUGAS)
    // -------------------------------------------------------------
    {
      id: 'validasi-paper',
      kicker: 'VALIDASI JURNAL ILMIAH',
      title: 'Teruji Hingga 1.000 Tugas di CloudSim',
      lead: 'Keunggulan FireBat telah divalidasi oleh para peneliti pada simulasi datacenter berskala besar.',
      render(container) {
        container.innerHTML = `
          <div class="slide">
            <span class="slide-kicker">VALIDASI JURNAL ILMIAH</span>
            <h1 class="slide-title">Kinerja Skala Besar di Datacenter</h1>
            <p class="slide-lead">
              Data resmi paper Pathania et al. (Springer Nature, 2026) pada 10 Datacenter &amp; 50 Mesin Virtual.
            </p>
            <div class="grid-3">
              <div class="clean-card card-gold">
                <div class="stat-label" style="color:var(--amber);">PENGHEMATAN WAKTU</div>
                <div class="stat-num" style="color:var(--amber);">↓ 50.9%</div>
                <p class="stat-desc">Makespan berkurang drastis dibanding Bat Algorithm pada 200 tugas.</p>
              </div>

              <div class="clean-card card-cyan">
                <div class="stat-label" style="color:var(--cyan);">KETIMPANGAN SERVER</div>
                <div class="stat-num" style="color:var(--cyan);">↓ 12.7%</div>
                <p class="stat-desc">Degree of Imbalance (DOI) ditekan konsisten dari 200 hingga 1.000 cloudlets.</p>
              </div>

              <div class="clean-card card-violet">
                <div class="stat-label" style="color:var(--violet);">PRODUKTIVITAS SISTEM</div>
                <div class="stat-num" style="color:var(--violet);">↑ 35.0%</div>
                <p class="stat-desc">Throughput tugas per detik meningkat tinggi berkat pembagian kerja yang adil.</p>
              </div>
            </div>
          </div>
        `;
      },
      notes: 'Tegaskan ke audiens bahwa ini bukan klaim sepihak kita di kelas, melainkan hasil riset resmi yang dipublikasikan di Springer Nature hingga skala 1.000 tugas.'
    },

    // -------------------------------------------------------------
    // SLIDE 7: KESIMPULAN & REFERENSI
    // -------------------------------------------------------------
    {
      id: 'penutup',
      kicker: 'KESIMPULAN DEMO 1',
      title: 'Ringkasan & Daftar Pustaka',
      lead: 'Seluruh ketentuan tugas minggu 13 telah terpenuhi dengan tuntas.',
      render(container) {
        container.innerHTML = `
          <div class="slide">
            <span class="slide-kicker">KESIMPULAN DEMO 1</span>
            <h1 class="slide-title">Siap Melangkah ke Demo 2</h1>
            <div class="grid-2" style="margin-top:20px;">
              <div class="clean-card card-gold" style="display:flex;flex-direction:column;justify-content:space-between;">
                <div>
                  <div style="font-size:20px;font-weight:700;color:var(--amber);margin-bottom:12px;">3 Kesimpulan Utama:</div>
                  <ul style="font-size:17px;line-height:1.7;color:var(--ink-primary);padding-left:20px;margin:0;">
                    <li><b>Hybrid Terpilih:</b> FireBat memadukan eksplorasi luas Firefly dan presisi Bat.</li>
                    <li><b>Terbukti Lebih Unggul:</b> Mengalahkan Firefly murni dan Bat murni di semua metrik.</li>
                    <li><b>Menuju Demo 2:</b> Algoritma ini siap diimplementasikan untuk studi kasus dunia nyata (Minggu 14).</li>
                  </ul>
                </div>
                <div style="margin-top:20px;font-size:15px;color:var(--amber);">
                  🚀 <b>Langkah Selanjutnya:</b> Demo 2 — Aplikasi di Real World Cloud.
                </div>
              </div>

              <div class="clean-card">
                <div style="font-size:15px;font-weight:700;color:var(--ink-secondary);text-transform:uppercase;letter-spacing:0.05em;margin-bottom:14px;">
                  Daftar Pustaka Wajib:
                </div>
                <div style="font-size:15px;line-height:1.6;color:var(--ink-secondary);">
                  <p style="margin:0 0 10px;">
                    <b style="color:var(--amber);">1. Paper Hybrid FireBat:</b><br/>
                    Pathania, N., Singh, B., Batra, I., Prashar, D., Khan, A. A., &amp; Kadry, S. (2026). <i>FireBat: a hybrid approach for load balancing in cloud computing</i>. <b>Journal of Cloud Computing</b>, 15(1), Article 5. Springer Nature.
                  </p>
                  <p style="margin:0 0 10px;">
                    <b style="color:var(--cyan);">2. Paper Asal Firefly:</b><br/>
                    Yang, X.-S. (2009). <i>Firefly Algorithms for Multimodal Optimization</i>. SAGA 2009, LNCS 5792, pp. 169–178. Springer.
                  </p>
                  <p style="margin:0;">
                    <b style="color:var(--violet);">3. Paper Asal Bat:</b><br/>
                    Yang, X.-S. (2010). <i>A New Metaheuristic Bat-Inspired Algorithm</i>. NICSO 2010, SCI 284, pp. 65–74. Springer.
                  </p>
                </div>
              </div>
            </div>
          </div>
        `;
      },
      notes: 'Tutup presentasi dengan elegan. Ucapkan terima kasih dan persilakan audiens untuk bertanya. Seluruh kriteria tugas: memilih hybrid dari paper, menjelaskan cara kerjanya secara sederhana, membandingkan dengan 2 metode sebelumnya, menyertakan visual 3D, dan mencantumkan sitasi ilmiah telah terpenuhi sempurna.'
    }
  ];

  global.CleanDeck = SLIDES;
})(window);
