/**
 * Unified 3D Interactive World Engine:
 * - Dynamic undulating continuous topological landscape
 * - Swarm Simulation Mode (Firefly cyan, Bat violet, FireBat gold) with Play/Step/Reset
 * - 4 Server Monoliths with live rising task load blocks (Makespan & Balance comparison)
 * - OrbitControls enabled so user can rotate/zoom in 3D freely!
 */
(function (global) {
  'use strict';

  function initInteractive3D(container) {
    let width = container.clientWidth || window.innerWidth;
    let height = container.clientHeight || window.innerHeight;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x040817);
    scene.fog = new THREE.FogExp2(0x040817, 0.024);

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 5.5, 14);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.maxPolarAngle = Math.PI / 2.05;
    controls.minDistance = 4;
    controls.maxDistance = 40;

    // Lights
    scene.add(new THREE.AmbientLight(0xffffff, 0.4));
    const lightGold = new THREE.PointLight(0xfbbf24, 1.8, 30);
    lightGold.position.set(6, 8, 4);
    scene.add(lightGold);

    const lightCyan = new THREE.PointLight(0x38bdf8, 1.5, 30);
    lightCyan.position.set(-6, 6, 2);
    scene.add(lightCyan);

    // 1. Continuous Wave Topology Floor
    const gridRows = 44, gridCols = 44;
    const gridGeo = new THREE.PlaneGeometry(32, 32, gridCols, gridRows);
    gridGeo.rotateX(-Math.PI / 2);
    const gridMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      wireframe: true,
      roughness: 0.5,
      metalness: 0.8
    });
    const gridMesh = new THREE.Mesh(gridGeo, gridMat);
    gridMesh.position.y = -1.2;
    scene.add(gridMesh);

    // 2. Swarm Particles for Live Interactive Simulation
    const swarmGroup = new THREE.Group();
    scene.add(swarmGroup);

    const sphereGeo = new THREE.SphereGeometry(0.18, 12, 12);
    function makeParticles(colorHex, count) {
      const g = new THREE.Group();
      const mat = new THREE.MeshStandardMaterial({ color: colorHex, emissive: colorHex, emissiveIntensity: 0.7 });
      for (let i = 0; i < count; i++) {
        const m = new THREE.Mesh(sphereGeo, mat);
        g.add(m);
      }
      return g;
    }

    const meshFA = makeParticles(0x38bdf8, 15);      // Cyan Kunang-kunang
    const meshBA = makeParticles(0xa855f7, 15);      // Violet Kelelawar
    const meshFB = makeParticles(0xfbbf24, 15);      // Emas FireBat
    meshFB.children.forEach(c => c.scale.setScalar(1.3));
    swarmGroup.add(meshFA);
    swarmGroup.add(meshBA);
    swarmGroup.add(meshFB);

    // 3. 4 Minimal Server Monoliths with Live 3D Task Heights
    const serverGroup = new THREE.Group();
    serverGroup.position.set(0, -1.2, -1.5);
    scene.add(serverGroup);

    const vmConfigs = [
      { name: 'VM-1 (Small)', mips: 85, color: 0xf87171, x: -4.5 },
      { name: 'VM-2 (Medium)', mips: 115, color: 0xfbbf24, x: -1.5 },
      { name: 'VM-3 (Large)', mips: 145, color: 0x38bdf8, x: 1.5 },
      { name: 'VM-4 (X-Large)', mips: 175, color: 0x4ade80, x: 4.5 }
    ];

    const serverPillars = [];
    vmConfigs.forEach((cfg) => {
      const g = new THREE.Group();
      g.position.set(cfg.x, 0, 0);

      // Base pedestal
      const base = new THREE.Mesh(
        new THREE.CylinderGeometry(0.8, 0.9, 0.3, 24),
        new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.3, metalness: 0.8 })
      );
      base.position.y = 0.15;
      g.add(base);

      // Dynamic load pillar (grows with task load in 3D)
      const loadBar = new THREE.Mesh(
        new THREE.BoxGeometry(0.9, 1, 0.9),
        new THREE.MeshStandardMaterial({ color: cfg.color, emissive: cfg.color, emissiveIntensity: 0.4 })
      );
      loadBar.position.y = 0.5;
      g.add(loadBar);

      // Light ring
      const ring = new THREE.Mesh(
        new THREE.RingGeometry(0.95, 1.05, 24),
        new THREE.MeshBasicMaterial({ color: cfg.color, side: THREE.DoubleSide })
      );
      ring.rotation.x = -Math.PI / 2;
      ring.position.y = 0.31;
      g.add(ring);

      serverGroup.add(g);
      serverPillars.push({ group: g, loadBar, cfg });
    });

    // Golden Makespan Target Line in 3D
    const targetLineGeo = new THREE.BoxGeometry(11, 0.04, 0.04);
    const targetLineMat = new THREE.MeshBasicMaterial({ color: 0xfbbf24 });
    const targetLineMesh = new THREE.Mesh(targetLineGeo, targetLineMat);
    targetLineMesh.position.set(0, 2.5, 0);
    serverGroup.add(targetLineMesh);

    // Initial Hide of server pillars until slide 5
    serverGroup.visible = false;
    swarmGroup.visible = false;

    // Camera viewpoints for slides
    const CAMERA_DESTS = [
      { pos: [0, 5.0, 13], target: [0, 1.2, 0] },     // 0: Cover
      { pos: [-3, 3.8, 10.5], target: [-1.2, 1.0, 0] }, // 1: Dilema
      { pos: [3, 4.0, 10], target: [1.0, 1.2, 0] },    // 2: 3 Pilar
      { pos: [0, 7.5, 11], target: [0, 0.5, 0] },      // 3: 3D Swarm Simulation
      { pos: [0, 2.8, 9.5], target: [0, 1.5, -1.5] },  // 4: 3D Server Balancing
      { pos: [-2, 3.5, 10.5], target: [0, 1.2, 0] },   // 5: Perbandingan
      { pos: [0, 5.0, 13], target: [0, 1.2, 0] }      // 6: Penutup
    ];

    let targetCamPos = new THREE.Vector3(0, 5.0, 13);
    let targetCamLook = new THREE.Vector3(0, 1.2, 0);
    let animId = null;
    let clock = new THREE.Clock();

    // Swarm Simulation Logic
    let swarmManager = global.SimEngine.create3DSwarm('rastrigin', 101);

    function syncSwarmMeshes() {
      const R = swarmManager.land.range;
      function sync(group, list) {
        for (let i = 0; i < list.length && i < group.children.length; i++) {
          const p = list[i];
          const m = group.children[i];
          const wx = (p.x / R) * 8;
          const wz = (p.z / R) * 8;
          m.position.set(wx, p.y * 0.12 - 0.2, wz);
        }
      }
      sync(meshFA, swarmManager.fireflies);
      sync(meshBA, swarmManager.bats);
      sync(meshFB, swarmManager.firebat);
    }
    syncSwarmMeshes();

    // Server Load Balancing Profiles
    const ALGO_LOADS = {
      firebat: [14.1, 14.4, 14.6, 14.2], // almost perfectly level (Makespan 14.6s)
      ba:      [15.2, 13.8, 14.0, 15.1], // Makespan 15.2s
      fa:      [15.8, 12.5, 13.2, 15.7], // Makespan 15.8s
      rr:      [21.4, 17.2, 14.1, 12.8]  // Small VM heavily overloaded (21.4s)
    };

    function updateServerLoads(algoKey) {
      const loads = ALGO_LOADS[algoKey] || ALGO_LOADS.firebat;
      const mk = Math.max(...loads);
      const scaleH = 0.24;

      serverPillars.forEach((p, idx) => {
        const val = loads[idx];
        const h = Math.max(0.2, val * scaleH);
        p.loadBar.scale.set(1, h, 1);
        p.loadBar.position.y = 0.3 + h / 2;

        // If overloaded, turn red
        if (val > 17) {
          p.loadBar.material.color.setHex(0xf43f5e);
          p.loadBar.material.emissive.setHex(0xf43f5e);
        } else {
          p.loadBar.material.color.setHex(p.cfg.color);
          p.loadBar.material.emissive.setHex(p.cfg.color);
        }
      });

      targetLineMesh.position.y = 0.3 + mk * scaleH;
    }
    updateServerLoads('firebat');

    function setSlideIndex(idx) {
      const dest = CAMERA_DESTS[idx] || CAMERA_DESTS[0];
      targetCamPos.set(dest.pos[0], dest.pos[1], dest.pos[2]);
      targetCamLook.set(dest.target[0], dest.target[1], dest.target[2]);

      // Show specific 3D interactive layers based on slide
      if (idx === 3) {
        swarmGroup.visible = true;
        serverGroup.visible = false;
      } else if (idx === 4) {
        swarmGroup.visible = false;
        serverGroup.visible = true;
      } else {
        swarmGroup.visible = false;
        serverGroup.visible = false;
      }
    }

    // Grid Floor Waves
    const posAttr = gridGeo.attributes.position;
    const initialY = new Float32Array(posAttr.count);
    for (let i = 0; i < posAttr.count; i++) initialY[i] = posAttr.getY(i);

    function animate() {
      animId = requestAnimationFrame(animate);
      const time = clock.getElapsedTime();

      // Smooth camera lerp
      camera.position.lerp(targetCamPos, 0.045);
      controls.target.lerp(targetCamLook, 0.045);
      controls.update();

      // Animate undulating floor
      for (let i = 0; i < posAttr.count; i++) {
        const x = posAttr.getX(i);
        const z = posAttr.getZ(i);
        const wave = Math.sin(x * 0.4 + time * 1.2) * Math.cos(z * 0.4 + time * 1.0) * 0.4;
        posAttr.setY(i, initialY[i] + wave);
      }
      posAttr.needsUpdate = true;

      renderer.render(scene, camera);
    }

    function resize() {
      width = container.clientWidth;
      height = container.clientHeight;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    }

    window.addEventListener('resize', resize);
    animate();

    return {
      setSlideIndex,
      stepSwarm() {
        const res = swarmManager.step();
        syncSwarmMeshes();
        return res;
      },
      resetSwarm(landKey, seed) {
        swarmManager = global.SimEngine.create3DSwarm(landKey, seed);
        syncSwarmMeshes();
      },
      setFilterSwarm(type) {
        meshFA.visible = (type === 'all' || type === 'fa');
        meshBA.visible = (type === 'all' || type === 'ba');
        meshFB.visible = (type === 'all' || type === 'firebat');
      },
      updateServerLoads,
      destroy() {
        window.removeEventListener('resize', resize);
        cancelAnimationFrame(animId);
        renderer.dispose();
      }
    };
  }

  global.Interactive3D = {
    initInteractive3D
  };
})(window);
